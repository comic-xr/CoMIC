There are 6 codes in this file.

The first two are TCP client and server for Laptop and HoloLens.

- The first code is named as TCP_Client (Python script) which runs on the Laptop as a client.

- The second code is named as TCP_Server (C# script) which is run on HoloLens after developing in Unity Engine as a project.



The next two are UDP client and server for laptop and HoloLens, where Hololens is a server and Laptop is a client.

And the Last two are UDP client and server for laptop and HoloLens, where Hololens is a client and Laptop is a server.
   
